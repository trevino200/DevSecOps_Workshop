from django.apps import AppConfig


class BadcommandConfig(AppConfig):
    name = 'badcommand'
